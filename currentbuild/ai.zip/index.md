# Home - Demo AllergyIntolerance Europa (EU Core/EHDS) og Norge v0.1.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/demo-at/ImplementationGuide/hl7.fhir.no.demo-at | *Version*:0.1.1 |
| Draft as of 2026-09-15 | *Computable Name*:DemoAT |

### Demo AllergyIntolerance Europa og Norge

Dette er en demo-IG som viser et enkelt oppsett for AllergyIntolerance.

### Mål

Dette IG'en er en demo for en HL7 FHIR implementasjonsguide for AllergyIntolerance. AllergyIntolerance skal basere seg på [HL7 Europe Base and Core FHIR IG R4](https://github.com/hl7-eu/base), og inneholde relevante norske utvidelser/tilpasninger.

UNDER ARBEID

Kontakt:

Espen Stranger Seland, Helsedirektoratet


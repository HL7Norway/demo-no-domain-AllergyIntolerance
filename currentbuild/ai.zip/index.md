# Home - Demo AT v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/demo-at/ImplementationGuide/hl7.fhir.no.demo-at | *Version*:0.1.0 |
| Draft as of 2026-09-15 | *Computable Name*:DemoAT |

### Demo AT

Dette er en demo-IG som viser et enkelt oppsett for AllergyIntolerance-beskrivelser med FHIR Shorthand.

### Mål

Målet med implementasjonsguiden er å demonstrere hvordan en norsk FHIR IG kan settes opp og brukes til å beskrive allergi- og intoleranseinformasjon.

### Omfang

Guiden inneholder:

* en enkel pasientprofil basert på NoBasisPatient
* en demo-profil for `AllergyIntolerance`
* eksempelinnhold som kan valideres og publiseres med de medfølgende workflowene

### Figur

Eksempel på en figur laget med PlantUML.

![](test.svg)


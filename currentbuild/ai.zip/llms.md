# hl7.fhir.no.demo-at#0.1.0: Demo AT

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Demo AllergyIntolerance](StructureDefinition-demo-at-allergy-intolerance.md)
* [Demo pasient](StructureDefinition-demo-at-patient.md)

### ImplementationGuides

* [Demo AT](index.md)

### Examples

* [DemoAtAllergyIntolerance-1 (AllergyIntolerance)](AllergyIntolerance-DemoAtAllergyIntolerance-1.md)
* [DemoAtPatient-1 (Patient)](Patient-DemoAtPatient-1.md)

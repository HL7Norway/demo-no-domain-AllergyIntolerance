# hl7.fhir.no.demo-at#0.1.1: Demo AllergyIntolerance Europa (EU Core/EHDS) og Norge

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [7514 Annen allergi som kritisk informasjon](CodeSystem-no-kodeverk-7514.codesystem.md)
* [7852 Allergener](CodeSystem-no-kodeverk-7852.codesystem.md)

### ValueSets

* [Allergener (7852)](ValueSet-allergener-7852.md)
* [Annen allergi som kritisk informasjon (7514)](ValueSet-annen-allergi-som-kritisk-informasjon-7514.md)

### Resource Profiles

* [Demo AllergyIntolerance](StructureDefinition-demo-at-allergy-intolerance.md)
* [Demo pasient](StructureDefinition-demo-at-patient.md)

### ImplementationGuides

* [Demo AllergyIntolerance Europa (EU Core/EHDS) og Norge](index.md)

### Examples

* [DemoAtAllergyIntolerance-1 (AllergyIntolerance)](AllergyIntolerance-DemoAtAllergyIntolerance-1.md)
* [DemoAtPatient-1 (Patient)](Patient-DemoAtPatient-1.md)
